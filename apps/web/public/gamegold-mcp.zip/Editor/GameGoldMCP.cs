using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading;
using UnityEditor;
using UnityEngine;

namespace GameGold.MCP
{
    /// <summary>
    /// Entry point. Opens an HTTP listener on localhost:7432 when the Editor starts,
    /// dispatches tool calls to the right handler, and shuts down cleanly on Editor quit.
    /// </summary>
    [InitializeOnLoad]
    public static class GameGoldMCP
    {
        private const int Port = 7432;

        // Only these origins may drive the Editor — anything else in a browser gets 403.
        // Without this, any website the developer visits could call localhost:7432.
        private static readonly string[] AllowedOrigins =
        {
            "https://gamegold.vercel.app",
            "http://localhost:3000",
            "http://localhost:3001", // local dev when 3000 is taken
        };

        private static HttpListener _listener;
        private static Thread _thread;
        private static volatile bool _running;

        // Unity APIs are main-thread only: listener threads enqueue work, EditorApplication.update drains it.
        private static readonly ConcurrentQueue<Action> _mainThreadQueue = new();

        // Cached on the main thread — Application.* must not be touched from listener threads.
        private static readonly string _unityVersion;
        private static readonly string _projectPath;
        private static readonly string _projectName;

        // All registered tools — add new ones here
        private static readonly Dictionary<string, Func<string, string>> _tools = new()
        {
            ["scene.list"]           = SceneTools.List,
            ["scene.new"]            = SceneTools.New,
            ["gameobject.create"]    = GameObjectTools.Create,
            ["gameobject.delete"]    = GameObjectTools.Delete,
            ["gameobject.find"]      = GameObjectTools.Find,
            ["component.add"]        = ComponentTools.Add,
            ["component.setField"]   = ComponentTools.SetField,
            ["asset.createScript"]   = AssetTools.CreateScript,
            ["asset.importSprite"]   = AssetTools.ImportSprite,
            ["asset.createText"]     = AssetTools.CreateText,
            ["playmode.enter"]       = PlayModeTools.Enter,
            ["playmode.exit"]        = PlayModeTools.Exit,
        };

        static GameGoldMCP()
        {
            _unityVersion = Application.unityVersion;
            _projectPath  = Application.dataPath.Replace("/Assets", "");
            _projectName  = System.IO.Path.GetFileName(_projectPath);

            EditorApplication.update += DrainMainThreadQueue;
            // Release the port before a domain reload, or the next Start() fails with "address in use"
            AssemblyReloadEvents.beforeAssemblyReload += Stop;
            EditorApplication.quitting += Stop;
            // Delay start until Editor is ready
            EditorApplication.delayCall += Start;
        }

        private static void DrainMainThreadQueue()
        {
            while (_mainThreadQueue.TryDequeue(out var action)) action();
        }

        [MenuItem("Window/GameGold MCP/Start Server")]
        public static void Start()
        {
            if (_running) return;

            try
            {
                _listener = new HttpListener();
                _listener.Prefixes.Add($"http://localhost:{Port}/");
                _listener.Start();
                _running = true;

                _thread = new Thread(Listen) { IsBackground = true };
                _thread.Start();

                Debug.Log($"[GameGold MCP] Server started on http://localhost:{Port}");
            }
            catch (Exception ex)
            {
                _running = false;
                try { _listener?.Close(); } catch { /* already broken */ }
                _listener = null;
                Debug.LogError($"[GameGold MCP] Could not start server on localhost:{Port} ({ex.Message}). " +
                               "Another Unity instance or process may be using the port. Retry via Window > GameGold MCP > Start Server.");
            }
        }

        [MenuItem("Window/GameGold MCP/Stop Server")]
        public static void Stop()
        {
            if (!_running) return;
            _running = false;
            try { _listener?.Stop(); _listener?.Close(); }
            catch (Exception ex) { Debug.LogWarning($"[GameGold MCP] Error while stopping: {ex.Message}"); }
            _listener = null;
            Debug.Log("[GameGold MCP] Server stopped.");
        }

        private static void Listen()
        {
            var listener = _listener;
            while (_running)
            {
                try
                {
                    var ctx = listener.GetContext();
                    ThreadPool.QueueUserWorkItem(_ => HandleRequest(ctx));
                }
                catch (Exception) when (!_running)
                {
                    break; // Normal shutdown
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[GameGold MCP] Listener error: {ex.Message}");
                }
            }
        }

        private static void HandleRequest(HttpListenerContext ctx)
        {
            var origin = ctx.Request.Headers["Origin"];
            bool browserRequest = !string.IsNullOrEmpty(origin);
            bool originAllowed = !browserRequest || Array.IndexOf(AllowedOrigins, origin) >= 0;

            if (originAllowed && browserRequest)
            {
                ctx.Response.Headers.Add("Access-Control-Allow-Origin", origin);
                ctx.Response.Headers.Add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
                ctx.Response.Headers.Add("Access-Control-Allow-Headers", "Content-Type");
                // Chrome Private Network Access: HTTPS page → localhost needs this on preflight
                if (ctx.Request.Headers["Access-Control-Request-Private-Network"] == "true")
                    ctx.Response.Headers.Add("Access-Control-Allow-Private-Network", "true");
            }
            ctx.Response.ContentType = "application/json";

            var path = ctx.Request.Url.AbsolutePath.TrimStart('/');
            bool isTool = path.StartsWith("tool/");

            try
            {
                string responseJson;

                if (!originAllowed)
                {
                    ctx.Response.StatusCode = 403;
                    responseJson = Error($"Origin not allowed: {origin}");
                }
                else if (ctx.Request.HttpMethod == "OPTIONS")
                {
                    // CORS preflight
                    ctx.Response.StatusCode = 204;
                    ctx.Response.Close();
                    return;
                }
                else if (path == "status")
                {
                    // The filesystem path only goes to allowlisted browser origins
                    var pathJson = browserRequest ? $",\"projectPath\":\"{EscapeJson(_projectPath)}\"" : "";
                    responseJson = $"{{\"status\":\"ok\",\"version\":\"{EscapeJson(_unityVersion)}\",\"projectName\":\"{EscapeJson(_projectName)}\"{pathJson}}}";
                }
                else if (isTool && ctx.Request.HttpMethod != "POST")
                {
                    ctx.Response.StatusCode = 405;
                    responseJson = Error("Tool calls require POST");
                }
                else if (isTool && !browserRequest)
                {
                    // Tool calls come from the GameGold web app, which always sends an allowlisted Origin
                    ctx.Response.StatusCode = 403;
                    responseJson = Error("Origin header required");
                }
                else if (isTool && !(ctx.Request.ContentType ?? "").StartsWith("application/json", StringComparison.OrdinalIgnoreCase))
                {
                    // Forces a CORS preflight, so cross-site "simple" requests can't reach tools
                    ctx.Response.StatusCode = 415;
                    responseJson = Error("Content-Type must be application/json");
                }
                else if (isTool)
                {
                    var toolName = path.Substring("tool/".Length);
                    var body = ReadBody(ctx.Request);

                    if (_tools.TryGetValue(toolName, out var handler))
                    {
                        // All Unity API calls must run on the main thread
                        string result = null;
                        var done = new ManualResetEventSlim(false);
                        _mainThreadQueue.Enqueue(() =>
                        {
                            try { result = handler(body); }
                            catch (Exception ex) { result = Error(ex.Message); }
                            finally { done.Set(); }
                        });
                        done.Wait(TimeSpan.FromSeconds(10));
                        responseJson = result ?? Error("Tool timed out");
                    }
                    else
                    {
                        ctx.Response.StatusCode = 404;
                        responseJson = Error($"Unknown tool: {toolName}");
                    }
                }
                else
                {
                    ctx.Response.StatusCode = 404;
                    responseJson = "{\"success\":false,\"message\":\"Not found\"}";
                }

                var bytes = Encoding.UTF8.GetBytes(responseJson);
                ctx.Response.ContentLength64 = bytes.Length;
                ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
            }
            catch (Exception ex)
            {
                var err = Encoding.UTF8.GetBytes(Error(ex.Message));
                ctx.Response.StatusCode = 500;
                ctx.Response.OutputStream.Write(err, 0, err.Length);
            }
            finally
            {
                ctx.Response.Close();
            }
        }

        internal static string ReadBody(HttpListenerRequest req)
        {
            if (!req.HasEntityBody) return "{}";
            using var reader = new System.IO.StreamReader(req.InputStream, req.ContentEncoding);
            return reader.ReadToEnd();
        }

        internal static string Ok(string message, string dataJson = "null")
            => $"{{\"success\":true,\"message\":\"{EscapeJson(message)}\",\"data\":{dataJson}}}";

        internal static string Error(string message)
            => $"{{\"success\":false,\"message\":\"{EscapeJson(message)}\"}}";

        internal static string EscapeJson(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            var sb = new StringBuilder(s.Length + 8);
            foreach (var c in s)
            {
                switch (c)
                {
                    case '"':  sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    case '\b': sb.Append("\\b"); break;
                    case '\f': sb.Append("\\f"); break;
                    default:
                        if (c < 0x20) sb.Append("\\u").Append(((int)c).ToString("x4"));
                        else sb.Append(c);
                        break;
                }
            }
            return sb.ToString();
        }
    }
}
